<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $file = fopen("users.txt", "r");
    $validUser = false;

    while (($line = fgets($file)) !== false) {
        list($restaurantName, $storedEmail, $storedPassword) = explode(",", trim($line));

        if ($email == $storedEmail && $password == $storedPassword) {
            $validUser = true;
            break;
        }
    }

    fclose($file);

    if ($validUser) {
        echo "Login successful! <a href='dashboard.html'>Go to Dashboard</a>";
    } else {
        echo "Invalid email or password. <a href='login.html'>Try again</a>";
    }
} else {
    echo "Invalid request method.";
}
?>