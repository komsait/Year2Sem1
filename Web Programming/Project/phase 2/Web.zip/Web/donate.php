<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $foodType = $_POST['foodType'];
    $quantity = $_POST['quantity'];
    $pickupDate = $_POST['pickupDate'];

    // Save donation information to a file
    $file = fopen("donations.txt", "a");
    fwrite($file, "$foodType,$quantity,$pickupDate\n");
    fclose($file);

    echo "Donation submitted successfully! <a href='dashboard.html'>Go back to Dashboard</a>";
} else {
    echo "Invalid request method.";
}
?>