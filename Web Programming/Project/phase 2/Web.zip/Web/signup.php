<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $restaurantName = $_POST['restaurantName'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Simple file-based storage for demonstration purposes
    $file = fopen("users.txt", "a");
    fwrite($file, "$restaurantName,$email,$password\n");
    fclose($file);

    echo "Sign up successful! <a href='login.html'>Login here</a>";
} else {
    echo "Invalid request method.";
}
?>